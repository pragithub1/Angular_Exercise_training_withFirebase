export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBWikSthMRtc-B4rA23fqxfjJ2TbZwvFNo",
    authDomain: "angular-training-app-119cb.firebaseapp.com",
    databaseURL: "https://angular-training-app-119cb.firebaseio.com",
    projectId: "angular-training-app-119cb",
    storageBucket: "angular-training-app-119cb.appspot.com",
    messagingSenderId: "1078284432576",
    appId: "1:1078284432576:web:b4a202e60b518c5495a925"
  }
};
